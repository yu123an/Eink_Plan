const char *mqtt_server = "chwhsen.xyz";
const char *ssid = "Nexus";
const char *password = "13033883439";